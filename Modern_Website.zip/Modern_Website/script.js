function handleMenu() {
    
}