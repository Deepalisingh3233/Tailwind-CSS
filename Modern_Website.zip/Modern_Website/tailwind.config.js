/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './**/*.js'], // adjust this to your project files
  theme: {
    extend: {
      colors: {
        avocado: {
          500: 'oklch(0.84 0.18 117.33)',
        },
      },
      fontFamily: {
        display: ['Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
